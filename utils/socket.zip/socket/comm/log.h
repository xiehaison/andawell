
#pragma once

#ifndef __LOG_H__
#define __LOG_H__

#define TIME_LEN 200
#define MAX_LOG_BUFFER_LEN 1024


void OutputLog(const char *fmt, ... );

#endif//__LOG_H__


