
#pragma once

#ifndef  __GLOBAL_H__
#define  __GLOBAL_H__

#include "comm.h"

#pragma  pack(1)

void OutputLog(const char *fmt, ... );

#pragma  pack()
#endif //__GLOBAL_H__
