//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� client.rc ʹ��
//
#define IDD_CLIENT_DIALOG               102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     129
#define IDC_Output                      1000
#define IDC_RIP                         1001
#define IDC_RPORT                       1002
#define IDC_CONNECT                     1003
#define IDC_SENDPACK                    1004
#define IDC_SENDBUF                     1005
#define IDC_NODE                        1006
#define IDC_CIN_CALLER                  1007
#define IDC_CIN_CALLED                  1008
#define IDC_CALLOUT                     1009
#define IDC_CIN_CHANNEL                 1010
#define IDC_HungUP                      1011
#define IDC_MSGTYPE                     1013
#define IDC_SendMSG                     1014
#define IDC_EDIT2                       1015
#define IDC_BREAK                       1016
#define IDC_BUTTON1                     1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
